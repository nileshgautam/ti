<section class="content">
        <div class="container-fluid">
            <div class="block-header">
                <h2>CREATE EMPLOYEE</h2>
            </div>

            <!-- Vertical Layout -->
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                    <br><br>
                        <!-- <div class="header"> -->
                            <!-- <h2>
                                VERTICAL LAYOUT
                            </h2>
                            <ul class="header-dropdown m-r--5">
                                <li class="dropdown">
                                    <a href="javascript:void(0);" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                                        <i class="material-icons">more_vert</i>
                                    </a>
                                    <ul class="dropdown-menu pull-right">
                                        <li><a href="javascript:void(0);">Action</a></li>
                                        <li><a href="javascript:void(0);">Another action</a></li>
                                        <li><a href="javascript:void(0);">Something else here</a></li>
                                    </ul>
                                </li>
                            </ul> -->
                        <!-- </div> -->
                        <div class="body">
                            <form>
                                <div class="col-sm-6">
                                    <label for="email_address">Employee Id</label>
                                    <div class="form-group">
                                        <div class="form-line">
                                            <input type="text" name="employeeId" id="email_address" class="form-control" placeholder="Enter Employee Id">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <label for="password">Employee Name</label>
                                    <div class="form-group">
                                        <div class="form-line">
                                            <input type="password" name="employeeName" id="password" class="form-control" placeholder="Enter Employee Name">
                                        </div>
                                    </div>
                                </div>

                                <div class="col-sm-6">
                                    <label for="email_address">Phone</label>
                                    <div class="form-group">
                                        <div class="form-line">
                                            <input type="text" name="phone" id="email_address" class="form-control" placeholder="Enter your email address">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <label for="password">Skills</label>
                                    <div class="form-group">
                                        <div class="form-line">
                                            <input type="password" name="Skills" id="password" class="form-control" placeholder="Enter your password">
                                        </div>
                                    </div>
                                </div>

                                <div class="col-sm-12">
                                    <label for="password">Address</label>
                                    <div class="form-group">
                                        <div class="form-line">
                                            <textarea name="address" class="form-control no-resize" placeholder="Enter Employee Address"></textarea>
                                        </div>
                                    </div>
                                </div>

                                <div class="colsm-12">
                                    <button type="button" class="btn btn-primary btn-block btn-lg waves-effect">SUBMIT</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </section>