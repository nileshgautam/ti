// $timeArray = [];
		// $timeArr = timeRange(7, 22);
		// $timeArraySlt = [];
		// $taskList = [];
		// for ($i = 0; $i < count($timeArr) - 1; $i++) { 
		// 	array_push()
		// }
		// print_r($timeArr);
		// print_r($task);die;
		// $temp = [];

		// for ($i = 0; $i < count($timeArr) - 1; $i++) {
		// 	if ($task) {
		// 		for ($j = 0; $j < count($task); $j++) {
		// 			$basetime = date("H:i:s", strtotime($timeArr[$i]));
		// 			$baseNext = date("H:i:s", strtotime($timeArr[$i + 1]));
		// 			$searchTime = $task[$j]['start_time'];
		// 			$searchEtime = $task[$j]['end_time'];

		// 			// echo  $timeArr[$i].' > '.$taskList[$searchTime] . '<br/>';
		// 			// print_r($timeArr[$i]) . '<br/>';


		// 			$st = explode(':', $searchTime);
		// 			$bt = explode(':', $basetime);

		// 			if ($st[0] == $bt[0]) {
				
		// 				if (($searchEtime <= $baseNext)) {
				
		// 					// for($k=0; $k<count($task); $k++){
		// 					// 	if($searchEtime <= $baseNext){

		// 					// 	}
		// 					// }



		// 					$taskList[$searchTime] = [$task[$j]];

		// 					$timeArraySlt[$timeArr[$i]] = $taskList[$searchTime];

		// 					// array_push($taskList[$searchTime]);


		// 					array_push($timeArraySlt ,$taskList[$searchTime]);

		// 				} else {
		// 					// $taskList[$searchTime] = [];
		// 					$timeArraySlt[$timeArr[$i]] = [];
				
		// 				}
			
		// 			} else {
		// 				// $taskList[$searchTime] = [];
		// 					$timeArraySlt[$timeArr[$i]] = [];
		// 			}
		// 			// echo 'hi';


		// 			// $timeArraySlt[$timeArr[$i]] = $taskList[$task[$j]['start_time']];
		// 			// $taskList[$task[$j]['start_time']]=[$task[$j]];
		// 		}

		// 		// $timeArraySlt[$timeArr[$i]]=array();

		// 		// print_r($timeArr[$i]);
		// 		// if($i==0 && $st[0] == $fxtime[0] && $tI1[1] == $tI2[1]){
		// 		// 	$submittedTask=['time' => $timeArr[$i],'id' =>[$data['task'][$j]]];
		// 		// 	array_push($timeArr, $submittedTask);
		// 		// }

		// 	} else {
		// 		$timeArraySlt[$timeArr[$i]] = array();
		// 	}
		// }

		// // print_r($taskList);
		// // print_r($temp);
		// print_r($timeArraySlt);
		// die;

		// print_r($timeArray);
		// die;